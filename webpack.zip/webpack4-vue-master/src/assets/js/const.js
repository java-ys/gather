
// 提示时间(毫秒)
const TIPS_TIEM = 2000;

// 分页每页条数数量
const PAGE_SIZE = 15;

export {
    TIPS_TIEM,
    PAGE_SIZE
}
