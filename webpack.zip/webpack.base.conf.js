const fs = require ('fs');
const path = require ('path');

module.exports = {
  entry: {},
  output: {},
  module: {
    rules: [
            {
                test: /\.ts$/,
                use: ['ts-loader']
            },
            {
                test: /\.tsx$/,
                use: [{
                    loader: 'babel-loader',
                    options: {
                        presets: ['es2015', 'react'],
                    }
                }, 'ts-loader'],
                exclude: /node_modules/
            },
            {
                test: /\.jsx$/,
                use: {
                    loader: 'babel-loader',
                    options: {
                        presets: ['es2015', 'react'],
                    }
                },
                exclude: /node_modules/
            },
            {
                test: /\.(gif|png|jpe?g|webp|svg)$/,
                use: [{
                    loader: 'url-loader',
                    options: {
                        // 小于2k 压缩，大于2k的用文件
                        limit: 1024 * 2,
                        name: '[name]-[hash:16].[ext]',
                        outputPath: "images"
                    }
                }]
            },
            {
                test: /\.(woff|woff2|eot|ttf|otf)$/,
                use: [{
                    loader: 'url-loader',
                    options: {
                        // 小于2k 压缩，大于2k的用文件
                        limit: 1024 * 2,
                        name: '[name]-[hash:16].[ext]',
                        outputPath: "fonts"
                    }
                }]
            },
            {
                test: /\.less$/,
                use: [{
                    loader: MiniCssExtractPlugin.loader,
                    options: {
                        publicPath: "../"
                    }
                }, 'css-loader', 'postcss-loader', 'less-loader']
            },
            {
                test: /\.s[c|a]ss$/,
                use: [{
                    loader: MiniCssExtractPlugin.loader,
                    options: {
                        publicPath: "../"
                    }
                }, 'css-loader', 'postcss-loader', 'sass-loader']
            },
            {
                test: /\.styl$/,
                use: [{
                    loader: MiniCssExtractPlugin.loader,
                    options: {
                        publicPath: "../"
                    }
                }, 'css-loader', 'postcss-loader', 'stylus-loader']
            },
            {
                test: /\.css$/,
                use: [{
                    loader: MiniCssExtractPlugin.loader,
                    options: {
                        publicPath: "../"
                    }
                }, 'css-loader', 'postcss-loader']
            },
    ]
  },
  plugins: [

  ],

  resolve: {
    alias: {
      '@': path.resolve(__dirname, '../src'),
    },
    extensions: ['.ts', '.js', '.json'],
  },
}