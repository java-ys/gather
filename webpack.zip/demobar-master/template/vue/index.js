import Vue from "vue";
import index from "./index.vue";

new Vue({
  render: h => h(index)
}).$mount("#app");
