<template>
  <div>adsfasd</div>
</template>
<script>
export default {
  el: "#app"
};
</script>
