import './main.css'

console.log('也许我是个js')