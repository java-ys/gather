const merge = require ('webpack-merge');
const baseConfig = require ('./webpack.base.conf.js');
module.exports = merge (baseConfig, {
  optimization: {
    runtimeChunk: {
      name: 'manifest',
    },
    splitChunks: {
      cacheGroups: {
        vendors: {
          name: 'vendor',
          filename: 'static/js/vendor.[chunkhash].js',
          test: /(vue|vuex)/,
          chunks: 'initial',
        },
      },
    },
  },
  plugins: [
    new copyWebpackPlugin({
			patterns: [
				{
					from: resolve("../client/public"),
					to: resolve("../client/dist")
				}
			]
		}),
  ]
});

const op1 = {
  optimization: {
      minimize: false,
      splitChunks: {
          cacheGroups: {
              vendor: {
                  test: /node_modules/,
                  chunks: 'initial',
                  name: 'chunk-vendor',
                  priority: 2
              },
              styles: {
                  name: 'styles',
                  test: /\.css$/,
                  chunks: 'all',
                  enforce: true
              }
          }
      }
  }
}

const op2 = {
  optimization: {
		splitChunks: {
			chunks: "all",
			minSize: 30000,
			minChunks: 2,
			maxAsyncRequests: 5,
			maxInitialRequests: 3,
			name: false,
			cacheGroups: {
				vender: {
					test: /[\\/]node_modules[\\/]/,
					chunks: "all",
					minSize: 0,
					minChunks: 2,
					priority: -10,
					name: "vendor"
				},
				common: {
					chunks: "all",
					minSize: 20000,
					minChunks: 2,
					name: "common",
					priority: -20,
				}
			}
		}
	}
}

const op4 = {
  optimization: {
        minimizer: [
            new UglifyJsPlugin({
                // 默认js
                test: /\.js(\?.*)?$/i,
                exclude: /\.min\.js$/,
                // 开启 sourceMap
                sourceMap: true,
                // 启用文件缓存
                cache: true,
                // 推荐，开启多线程（可设置运行线程数量）
                parallel: true,
                // 配置项
                uglifyOptions: {
                    compress: {
                        unused: true,
                      warnings: false,
                      drop_console: true,
                      drop_debugger: true,
                      reduce_vars: true
                  },
                  output: {
                        comments: false
                  }
                },
                // 是否把注释提到单独的文件中（[name].[ext].LICENSE）
                extractComments: false
            }),
            new OptimizeCssAssetsPlugin({
                assetNameRegExp: /\.css$/g,
                cssProcessorOptions: {
                    preset: ['default', {
                        autoprefixer: true,
                        discardComments: {
                            removeAll: true,
                        },
                        zindex: false
                    }]
                },
                canPrint: false
            })
          ],
          splitChunks: {
            chunks: 'async',
            minSize: 30000,
            minChunks: 1,
            maxAsyncRequests: 5,
            maxInitialRequests: 3,
            automaticNameDelimiter: '~',
            name: true,
            cacheGroups: {
                vendors: {
                    test: /[\\/]node_modules[\\/]/,
                    priority: -10,
                    name: 'vendors/vendors',
                    reuseExistingChunk: true,
                      chunks: 'async'
                },
                default: {
                    minChunks: 2,
                    priority: -20,
                    name: 'vendors/common',
                    reuseExistingChunk: true,
                    chunks: 'all'
                }
            }
        }
    },
}