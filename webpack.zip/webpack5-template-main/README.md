# webpack5 template

## author

- [charlie](https://charliegogh.github.io/)

## Installation

Clone this repo and npm install.

```bash
npm i
```

## Usage

### Development server

```bash
npm run serve
```

### Production build

```bash
npm run build
```


