require('./index.scss');
require("../../js/mobile");