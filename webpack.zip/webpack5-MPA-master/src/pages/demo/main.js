import styles from './style';

import configs from '@/configs';