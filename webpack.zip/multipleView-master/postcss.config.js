module.exports = {
    plugins: {
        autoprefixer: {}
    }
}
