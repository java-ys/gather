module.exports = {
    dev: {
        publicPath: '',
        host: 'localhost',
        port: 5000
    },
    prod: {
        publicPath: '/pages',
        outputPath: 'pages'
    }
}
