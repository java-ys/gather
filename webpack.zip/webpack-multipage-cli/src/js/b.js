import style from '../css/b.css'
import port from '../js/portConfig.js'

console.log('this is page b');
console.log(port);
