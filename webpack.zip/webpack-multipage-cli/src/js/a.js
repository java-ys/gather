import style from '../css/a.css'

import port from '../js/portConfig.js'

console.log('this is page a');

console.log(port);
