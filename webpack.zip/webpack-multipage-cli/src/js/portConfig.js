const port = 'Your ajax Interface Prefix'
export default port
