require("./page1.css");

document.getElementById('title').innerText = 'webpack test';
document.getElementById('content').innerText = require("@/common/runoob2.js");
