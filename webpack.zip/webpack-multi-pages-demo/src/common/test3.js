const test3Js = {
    msg: 'this is test3.js'
}

export default test3Js