module.exports = {
    outputDirName: 'dist',
    devServerPort: 8080
};
