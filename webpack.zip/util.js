const getEntries = () => {
  let result = fs.readdirSync (pagesDirPath);
  let entry = {};
  result.forEach (item => {
    entry[item] = path.resolve (__dirname, `../src/pages/${item}/index.js`);
  });
  return entry;
};

/**
 * 扫描pages文件夹，为每个页面生成一个插件实例对象
 */
const generatorHtmlWebpackPlugins = () => {
  const arr = [];
  let result = fs.readdirSync (pagesDirPath);
  result.forEach (item => {
    //判断页面目录下有无自己的index.html
    let templatePath;
    let selfTemplatePath = pagesDirPath + `/${item}/index.html`;
    let publicTemplatePath = path.resolve (
      __dirname,
      '../src/public/index.html'
    );
    try {
      fs.accessSync (selfTemplatePath);
      templatePath = selfTemplatePath;
    } catch (err) {
      templatePath = publicTemplatePath;
    }
    arr.push (
      new HtmlWebpackPlugin ({
        template: templatePath,
        filename: `${item}.html`,
        chunks: ['manifest', 'vendor', item],
      })
    );
  });
  return arr;
};


const ExtractTextPlugin = require ('extract-text-webpack-plugin');
const cssLoaders = (options = {}) => {
  const cssLoader = {
    loader: 'css-loader',
    options: {
      sourceMap: options.sourceMap,
    },
  };
  const postcssLoader = {
    loader: 'postcss-loader',
    options: {
      sourceMap: options.sourceMap,
    },
  };

  const generateLoaders = (loader, loaderOptions) => {
    const loaders = options.usePostCSS
      ? [cssLoader, postcssLoader]
      : [cssLoader];

    if (loader) {
      loaders.push ({
        loader: `${loader}-loader`,
        options: Object.assign ({}, loaderOptions, {
          sourceMap: options.sourceMap,
        }),
      });
    }

    if (options.extract) {
      return ExtractTextPlugin.extract ({
        use: loaders,
        fallback: 'vue-style-loader',
      });
    } else {
      return ['vue-style-loader'].concat (loaders);
    }
  };

  return {
    css: generateLoaders (),
    postcss: generateLoaders (),
    less: generateLoaders ('less'),
    sass: generateLoaders ('sass', {indentedSyntax: true}),
    scss: generateLoaders ('sass'),
    stylus: generateLoaders ('stylus'),
    styl: generateLoaders ('stylus'),
  };
};


// rules
const loaders = (USE_HASH = false) => {
  return [
    {
      test: /\.(js|jsx)/,
      loader: 'eslint-loader',
      enforce: 'pre',
      options: {
        formatter: eslintFormatter,
      },
      exclude: /node_modules/,
      include: [resolve ('../src')],
    },
    {
      test: /\.(js|jsx)$/,
      loader: 'babel-loader?cacheDirectory=true',
    },
    {
      test: /\.vue$/,
      loader: 'vue-loader',
    },
    {
      test: /\.pug$/,
      use: [
        'raw-loader',
        {
          loader: 'pug-html-loader',
          options: {
            data: {
              PROJECT_TITLE: Client.PROJECT_TYPE,
              SERVICE_RUN_MODE: Client.SERVICE_RUN_MODE,
            },
            basedir: resolve ('../client/src'),
          },
        },
      ],
    },
    {
      test: /\.css$/,
      use: [
        USE_HASH ? extractCss.loader : 'style-loader',
        'css-loader',
        'postcss-loader',
      ],
    },
    {
      test: /\.s(a|c)ss$/,
      use: [
        USE_HASH ? extractCss.loader : 'style-loader',
        'css-loader',
        'postcss-loader',
        'sass-loader',
      ],
    },
    {
      test: /(png|jpe?g|webp|gif)$/,
      loader: 'url-loader',
      options: {
        limit: 10 * 1024 * 1024,
        outputPath: 'image',
        name: USE_HASH ? '[name].[hash:4].[ext]' : '[name].[ext]',
        esModule: false,
      },
    },
    {
      test: /\.(woff(2)?|eot|ttf|otf|svg)(\?v=\d+\.\d+\.\d+)??$/,
      loader: 'url-loader',
      options: {
        limit: 20 * 1024 * 1024,
        outputPath: 'fonts',
        name: USE_HASH ? '[name].[hash:4].[ext]' : '[name].[ext]',
        esModule: false,
      },
    },
    {
      test: /\.(mp4|webm|ogg|mp3|wav|flac|aac)(\?.*)?$/,
      loader: 'url-loader',
      options: {
        limit: 51200,
        outputPath: 'medias',
        name: USE_HASH ? '[name].[hash:4].[ext]' : '[name].[ext]',
        esModule: false,
      },
    },
  ];
};
