import '~/style/common/index.less'
// process.env.env
var env = process.env.NODE_ENV
import $ from 'jquery'
import 'bootstrap'
window.$ = $
