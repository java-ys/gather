class def {
    name = '111';
    constructor () {
        this.name = 'home';
    }
}

module.exports = def;