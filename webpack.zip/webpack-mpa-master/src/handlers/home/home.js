
import '../../style/home/index.less'

// import idx from './index.ts'

// const a = new idx();
// console.log(a.name)

// import $ from 'jquery'

// $('body').attr('class','123')
