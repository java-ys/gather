class abc {
    name = '';
    constructor () {
        this.name = "ceshi";
    }
}

module.exports = abc;