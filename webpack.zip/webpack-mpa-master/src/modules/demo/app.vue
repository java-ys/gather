<template>
  <div class="container">
    Hello Vue!!!
  </div>
</template>

<script>
export default {
}
</script>

<style lang="less" scoped>
    .container{
        height: 100px;
        background-color: #f0f0f0;
    }
</style>