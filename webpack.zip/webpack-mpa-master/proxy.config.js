module.exports = {
    //内网环境代理地址+配置
    // '/api': {
    //     target: 'http://192.168.205.6:8769/',
    //     changeOrigin: true,
    //     pathRewrite: {
    //         '^/api': '/'
    //     }
    // }

    //集测（qa）环境代理地址+配置
    // '/api': {
    //     target: 'http://192.168.205.6:8888/', // qa环境
    //     changeOrigin: true,
    //     pathRewrite: {}
    // }
}
