import Vue from "vue";
import App from "./index.vue";
new Vue({
    render: h => h(App),
    el: "#root"
});