### 运行
npm run dev
服务会在运行在http://0.0.0.0:8086（端口号在webpack.dev.conf.js文件中更改）
在路径后面输入对应页面名称即可访问

### 打包
npm run build