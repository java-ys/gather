module.exports = {
  mode: "development",
  devtool: "inline-source-map",
  devServer: {
    // hot: true,
    disableHostCheck: true,
    inline: true,
    port: 4001,
    open: true,
    openPage: 'index.html',
    contentBase: [
      path.resolve(__dirname, '../src/pages/index'),
      path.resolve(__dirname, '../src/dashboard/index'),
    ],
    proxy: {
      '/dev': {
        target: EnvConfig.DEV_URL,
        changeOrigin: true,
        pathRewrite: {
          '^/dev': '',
        },
        logLevel: 'debug',
      },
    },
  },
}