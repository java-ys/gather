/*
 *		Generic much page project
 * File Name    : .postcssrc.js
 * Create On    : 2020-08-03 19:30:29
 * Create By    : Peachick <wsm_1105@163.com>
 * Copyright (c) 2019-present github.com/Peachick. All rights reserved.
 */


module.exports = {
	plugins: [
		require("autoprefixer")
	]
}
