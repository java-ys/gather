/*
 *      Generic much page project.
 *  FileName:   index.js
 *  Create On:  2020/11/29 15:35
 *  Create By:  Peachick <wsm_1105@163.com>
 *  Copyright (c) 2017-present github.com/Peachick. All rights reserved.
 */

const db = require("../../db/mysql")

module.exports = db
