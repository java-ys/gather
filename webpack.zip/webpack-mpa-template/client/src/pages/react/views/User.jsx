import React from "react"

const User = () => {
	return (
		<div>
			React User...
		</div>
	)
}

export default User
