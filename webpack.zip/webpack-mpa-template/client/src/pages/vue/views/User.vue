<template>
	<div class="user">
		Vue User...
	</div>
</template>

<script>
export default {
	name: "User"
}
</script>

<style lang="scss" scoped>
.user{
	font-weight: 600;
	font-size: 20px;
}
</style>
