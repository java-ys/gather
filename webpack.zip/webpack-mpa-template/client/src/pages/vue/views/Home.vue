<template>
	<div class="home">
		Vue Home...
	</div>
</template>

<script>
export default {
	name: "Home"
}
</script>

<style lang="scss" scoped>
.home{
	color: teal;
	font-size: 30px;
	font-weight: 700;
}
</style>
