module.exports = {
  extends: 'stylelint-config-ali',
};
