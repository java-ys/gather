module.exports = {
  enableStylelint: true,
  enableMarkdownlint: true,
  enablePrettier: true,
};
