module.exports = {
  extends: ['ali'],
};
