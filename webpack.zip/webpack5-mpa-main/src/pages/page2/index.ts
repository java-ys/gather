import '/@/assets/css/tailwind.css';
import './index.scss';
