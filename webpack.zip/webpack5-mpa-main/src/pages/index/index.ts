import 'core-js';
import '/@/assets/css/tailwind.css';
import '/@/assets/scss/common.scss';
import './index.scss';

document.title = process.env.APP_TITLE;
