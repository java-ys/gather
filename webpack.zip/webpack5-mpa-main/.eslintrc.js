module.exports = {
  extends: [
    'eslint-config-ali/typescript',
    'prettier',
    'prettier/@typescript-eslint',
  ],
};
