## 22-8-30
[uni-app 使用](https://juejin.cn/post/7137195631151415333#heading-27)

[开发过程常用模式](https://juejin.cn/post/6844904032826294286)
[性能优化](https://juejin.cn/post/7137058832592666655#heading-6)
[api数据缓存](https://juejin.cn/post/6844903843092758541#heading-1)
[前端发展](http://www.godbasin.com/vue-ebook/vue-ebook/0.html#%E5%89%8D%E7%AB%AF%E6%A1%86%E6%9E%B6%E7%9A%84%E5%87%BA%E7%8E%B0-2)


## 22-8-31
[前端监控和埋点](https://juejin.cn/post/6844904130163507214)
