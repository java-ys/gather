
describe('Dep', () => {


	it('new Set ', () => {
		// const set = new Set([1])

		// console.log(set)


	});


});