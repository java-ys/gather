module.exports = {
  outputDir: 'temp',
  devServer: {
    disableHostCheck: true
  }
};
