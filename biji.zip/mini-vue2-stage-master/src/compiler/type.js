/*
 * @Author: 毛毛 
 * @Date: 2022-04-14 13:09:23 
 * @Last Modified by: 毛毛
 * @Last Modified time: 2022-04-14 13:10:07
 * 节点类型
 */
// 元素类型
const ELEMENT_TYPE = 1;
// 文本类型
const TEXT_TYPE = 3;

export{
  ELEMENT_TYPE,
  TEXT_TYPE
}