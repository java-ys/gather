// babel config
module.exports =  {
  // 预设
  presets: ["@babel/preset-env"],
};
